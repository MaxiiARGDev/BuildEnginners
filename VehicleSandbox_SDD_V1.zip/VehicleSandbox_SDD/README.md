# Vehicle Sandbox — documentación SDD

Especificación inicial del proyecto Roblox multijugador. Nombre provisional.

## Índice
- [Visión y alcance](docs/01-VISION.md)
- [Gameplay y ciclo de vida](docs/02-GAMEPLAY.md)
- [Arquitectura y replicación](docs/03-ARCHITECTURE.md)
- [Catálogo de piezas y estadísticas](docs/04-ITEM-CATALOG.md)
- [Construcción, físicas y daño](docs/05-BUILD-PHYSICS-DAMAGE.md)
- [Economía, cajas y entregas](docs/06-ECONOMY-CRATES-DELIVERIES.md)
- [Misiones y mapa](docs/07-MISSIONS-WORLD.md)
- [Datos, seguridad y rendimiento](docs/08-DATA-SECURITY-PERFORMANCE.md)
- [MVP, pruebas y criterios de aceptación](docs/09-MVP-TESTING.md)
- [Decisiones pendientes](docs/10-OPEN-DECISIONS.md)
- [Instrucciones para agentes](AGENTS.md)

Los valores etiquetados **TBD** no están definidos. Las recomendaciones técnicas son propuestas, no decisiones confirmadas del producto.
