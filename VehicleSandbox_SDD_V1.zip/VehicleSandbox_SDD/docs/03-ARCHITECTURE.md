# 03 — Arquitectura de software

## Stack
Roblox Studio, Luau, Rojo; integración con herramientas de desarrollo asistido opcional.

## Árbol sugerido
```text
ReplicatedStorage/
  Shared/
    Config/{GameConfig,EconomyConfig,PhysicsConfig,RarityConfig}
    Catalog/{ItemRegistry,Definitions/{Structures,Wheels,Engines,Boosters,FuelTanks,Utilities}}
    Building/{GridMath,PlacementRules,ConnectionRules}
    Types/{ItemTypes,VehicleTypes}
    Remotes/
ServerStorage/
  ItemAssets/{Structures,Wheels,Engines,Boosters,FuelTanks,Utilities}/
  Crates/
  BaseTemplate/
  MissionAssets/
ServerScriptService/
  Server/
    Services/{PlotService,InventoryService,BuildingService,VehicleService,VehiclePhysicsService,DamageService,ItemRuntimeService,ShopService,StockService,DeliveryService,CrateService,EconomyService,DistanceService,MissionService,DataService}
    Bootstrap.server.lua
StarterPlayer/StarterPlayerScripts/Client/Controllers/
  {BuildController,VehicleController,CameraController,ShopController,UIController}
```

## Contratos principales
- `ItemRegistry.Get(itemId)`: definición validada, inmutable.
- `PlotService.Assign(player)`: estación libre y referencias por identificadores, no rutas Base1.
- `BuildingService.ApplyEdit(player, operation, revision)`: valida propiedad, inventario, límites, geometría y revisión; devuelve ack o rechazo.
- `VehicleService.Launch(player)`: bloquea blueprint, crea runtime, ensambla, activa conducción.
- `VehicleService.Return(player, reason)`: operación idempotente; limpia runtime y restaura modo edición.
- `DamageService.ApplyImpact(runtimeId, partInstanceId, impact)`: solo modifica estado temporal.
- `ItemRuntimeService.Init(runtime, part) / Destroy(runtime, part)`: comportamiento por categoría o por modelo.

## Modelo y comportamiento
- Definiciones autoritativas en módulos del servidor; opcionalmente replicar solo metadatos públicos al cliente.
- Modelos dentro de `ServerStorage.ItemAssets/<Category>/<ItemId>`; atributos para identificadores y puntos de conexión.
- Si el objeto requiere comportamiento propio, puede incluir `Behaviors/<ModuleScript>`; lo carga el orquestador central después de validar identidad y contrato.
- Nunca confiar en `Attributes`, precios, rarezas o estadísticas enviados por el cliente.
- Separar el `ItemId` del `InventoryInstanceId` para objetos obtenidos con rarezas y propiedades únicas.

## Edición inmediata
- Preview y colocación provisional locales en el mismo frame cuando sea posible.
- Cliente envía operación con ID y revisión; servidor valida, confirma y replica.
- Ante rechazo, rollback visual; ante conflictos, reconciliación desde estado autorizado.
- No prometer latencia de red real de 0 ms.

## Multijugador
- Diez estaciones exclusivas; propiedad y permisos comprobados en servidor.
- Cada jugador construye su propio vehículo en la V1; colaboración en un mismo vehículo no está confirmada.
- Vehículos runtime pueden utilizar NetworkOwnership para suavidad, pero la economía, daño autoritativo y recompensas se verifican en servidor.
