# 04 — Catálogo y estadísticas

## Categorías
- `Structures`: peso, durabilidad, precio.
- `Wheels`: equipación (`eq`, significado exacto TBD), agarre, peso, durabilidad, precio.
- `FuelTanks`: subtipo combustible normal o nitro; capacidad, tipo, peso, durabilidad, precio.
- `Utilities`: peso, durabilidad, restricciones de compra.
- `Engines`: velocidad, par, bonificación por conducción, tasa de desconexión (semántica TBD), combustible, consumo, peso, durabilidad, impulso/aumento de velocidad cuando aplique, precio.
- `Boosters`: bonificación por conducción, combustible cohete, combustible integrado, consumo, impulso, aumento de velocidad, peso, durabilidad.
- `Decorations`, `Other`: previstas, definición pendiente.

## Valores proporcionados por el diseñador
| ItemId sugerido | Categoría | Datos |
|---|---|---|
| WoodBeam | Structures | peso 1.8, durabilidad 70, precio 8 |
| WoodBlock | Structures | peso 5, durabilidad 75, precio 10 |
| SmallWheel | Wheels | peso 4, durabilidad 32, precio 25, eq 0.6, agarre 1.1 |
| RegularFuelTank | FuelTanks | tipo elegible Regular/Diesel/Competición al colocar; capacidad 1.5, peso 8, durabilidad 100, precio 175 |
| SmallNitroTank | FuelTanks | tipo RocketFuel, capacidad 28,800, peso 12, durabilidad 100, precio TBD |
| DriverSeat | Utilities | peso 8, durabilidad 300, máximo 1 compra por jugador; precio TBD |
| PassengerSeat | Utilities | peso 8, durabilidad 300, precio TBD |
| SmallEngine | Engines | velocidad 36 bloques/s con regular; torque 1400; bonificación +0.0025x; tasa de desconexión 21.88 monedas/hora; combustible normal; integrado 0.54; consumo máximo regular 0.18; peso 8; durabilidad 110; precio individual TBD |
| MediumEngine | Engines | velocidad 50 bloques/s con regular; torque 4200; bonificación +0.015x; tasa de desconexión 87.5 monedas/hora; combustible normal; integrado 0.9; consumo máximo regular 0.3; peso 14; durabilidad 150; precio individual TBD |
| SmallBooster | Boosters | bonificación +0.3x; RocketFuel; integrado 24,000; consumo en potenciación 12,000; impulso 12,000; aumento velocidad 1x; peso 12; durabilidad 130; precio individual TBD |

Los números se preservan como fueron especificados; las unidades y fórmulas de varios campos todavía requieren definición.

## Contrato de definición (ilustrativo)
```lua
return {
  Id = "WoodBeam",
  Category = "Structures",
  Model = "WoodBeam",
  Stats = { Weight = 1.8, MaxDurability = 70 },
  Price = 8,
  Behavior = nil,
}
```

## Regla de extensibilidad
Agregar modelo, definición, attachments/puntos de unión y opcionalmente módulo de comportamiento. El registro detecta conflictos de ID, atributos ausentes, modelos faltantes y estadísticas inválidas al iniciar. No modificar el servicio de construcción por cada pieza nueva.
