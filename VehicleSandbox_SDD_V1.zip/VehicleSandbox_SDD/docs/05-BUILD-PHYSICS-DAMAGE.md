# 05 — Construcción, física y daño

## Editor
- Área de edición de cada estación, vista previa local, colocación, rotación, borrado, snap a conexiones y validación del servidor.
- Stand desplaza vehículo completo arriba/abajo/izquierda/derecha en modo edición; no altera offsets relativos de piezas.
- Grid, dimensiones y controles exactos: TBD.
- Servidor valida límites de zona, intersecciones, presupuesto de piezas, cantidad disponible y propiedad.

## Modelo de construcción
- Blueprint: lista de piezas con `InstanceId`, `ItemId`, transform local, `InventoryInstanceId` cuando corresponda, configuración y conexiones explícitas de articulaciones.
- Cada pieza tiene geometría y puntos de conexión declarados.
- Estructuras rígidas con `WeldConstraint`; ruedas con constraints articulados.
- Componentes funcionales se coordinan por controlador de vehículo, sin script Heartbeat por pieza.

## Lanzamiento
1. Servidor congela revisión de blueprint autorizada.
2. Genera runtime independiente centrado en `LaunchPoint`.
3. Inicializa durabilidad de todas las piezas a `MaxDurability` y estado temporal de combustible.
4. Construye uniones y articulaciones, habilita fuerzas y control.
5. Desancla solo lo necesario y habilita conducción.

## Daño
- No calcular daño únicamente por `Touched`.
- Estimar severidad de impacto a partir de velocidad relativa y contexto físico, con umbrales y debounce.
- Servidor mantiene `CurrentDurability` por `partInstanceId` en runtime.
- A 0 HP: deshabilitar comportamiento, quitar conexiones, identificar grupos desconectados mediante grafo de conectividad y permitir desprendimientos.
- Escombros temporales con cleanup automático.
- Evitar exploits derivados de NetworkOwnership y reportes falsos de colisiones; la metodología exacta de validación se ajustará mediante pruebas.

## Regreso
- Destruir runtime, detener simuladores y limpiar escombros.
- Reubicar personaje en estación y reconstituir representación de edición desde blueprint.
- Restaurar durabilidad completa sin gastar piezas ni dinero.
- El blueprint nunca recibe cambios de daño.

## Criterios de prueba
- Romper rueda no borra su entrada en blueprint.
- Romper un bloque central desconecta únicamente grupos sin ruta de conexión.
- Dos piezas conectadas por otra ruta permanecen unidas.
- Tras Return, posiciones, configuraciones, rarezas y durabilidad son idénticas a las anteriores al lanzamiento.
- Llamar Return dos veces no duplica vehículo ni inventario.
