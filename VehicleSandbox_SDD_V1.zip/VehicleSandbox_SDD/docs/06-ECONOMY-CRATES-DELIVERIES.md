# 06 — Economía, cajas, stock y entregas

## Economía
Moneda: dinero. Recompensas por distancia y misiones; bonificaciones de motores/propulsores según configuración. Fórmula exacta de ganancias, límites y tasas: TBD.

## Tienda
Categorías: piezas, motores, propulsores, combustibles, decoraciones y otros. Los objetos limitados sujetos a stock se compran con entrega diferida.

## Stock por servidor
- Cupos compartidos por los 10 jugadores del mismo servidor.
- Ejemplo: stock 2, compra de una unidad deja 1 para todos.
- Reabastecimiento con cantidad aleatoria entre 1 y 3 unidades en cada renovación.
- **Pendiente**: frecuencia de renovación de stock; no asumir que coincide con el camión de 15 minutos.
- Compra atómica en servidor, evitando doble venta concurrente.

## Entrega
- Camión llega cada 15 minutos y entrega pedidos pendientes en estaciones.
- Comprar registra pedido; no agrega inmediatamente al inventario.
- Posibilidad de adelantar entrega pagando (moneda o Robux TBD).
- Pedidos persistentes y reclamables tras desconexión; definir política si el servidor cierra.
- Evitar duplicaciones por reconexión, entrega repetida o fallo de guardado.

## Cajas de motores
- `BasicEngineCrate`: precio 80; contiene motores de tamaños pequeño, mediano y grande, con probabilidades configurables.
- Otras cajas como `RoadEngineCrate`: pendientes.
- `BasicBoosterCrate`: precio 45,000; propulsores pequeños, medianos y grandes, probabilidades configurables.
- Dos dimensiones de sorteo: variante/tamaño y rareza; la distribución puede variar por caja.
- Rarezas: Común, No común, Raro, Épico, Legendario, Mítico.
- Cada rareza aumenta bonificación económica; valores y tablas autoritativas por caja.
- Capturas de referencia muestran para algunos motores bonificaciones como +0.0029x, +0.0034x, +0.0041x, +0.0051x, +0.0065x y porcentajes parciales. **No tomar capturas parciales como una tabla completa ni inventar porcentajes faltantes**.
- Resolver resultado y descontar caja en servidor; inventario recibe instancia única con tipo, rareza y estadísticas derivadas verificables.

## Integridad
- Transacciones con ID único e idempotencia.
- No aceptar precio, cantidad, rareza ni resultado de caja desde cliente.
- Guardar pedidos y entrega en un estado coherente ante fallos.
