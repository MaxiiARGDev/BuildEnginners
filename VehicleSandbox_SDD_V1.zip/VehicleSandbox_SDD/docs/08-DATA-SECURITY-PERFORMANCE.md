# 08 — Persistencia, seguridad y rendimiento

## Datos persistentes por jugador (propuesta)
- `SchemaVersion`, `Money`, `Inventory` (instancias únicas), `Blueprints`, `ActiveBlueprintId`, `PendingDeliveries`, `MissionProgress`, `Unlocks`.
- NO persistir `CurrentDurability` del runtime ni restos de choque.
- `InventoryInstanceId` único para motores/propulsores con rareza.
- Migraciones versionadas; límite de tamaño de blueprint y compresión/serialización donde sea necesario.

## Estado efímero por servidor
- Asignación de estaciones, stock local, tiempo hasta próximo camión, misiones activas de servidor, runtime de vehículos.
- Determinar qué estado efímero debe recuperarse tras reinicio para evitar pérdidas de compras.

## Seguridad
- Validar ownership, distancia/área de edición, cantidades, ID de objeto, rate limits, transformaciones, precios y revisiones.
- No permitir remotes que alteren HP, dinero, resultados de cajas o inventario sin lógica de servidor.
- Control de operaciones concurrentes e idempotencia de compras, entregas y retorno.
- Los cambios del cliente son propuestas, no autoridad.

## Rendimiento
- Objetivo: respuesta visual de construcción inmediata; medir tiempo de ack real.
- Probar 10 jugadores con vehículos activos y cargas progresivas de piezas/constraints.
- Configurar límites de piezas, escombros y distancia de simulación tras perfilar; valores TBD.
- Usar StreamingEnabled para mapa extenso, pooling donde convenga y limpieza de efectos temporales.
- Evitar un `Heartbeat` por pieza y recalcular grafo solo al cambiar conectividad.

## Observabilidad
- Métricas: tiempo de colocación local/ack, tiempo de lanzamiento, piezas por vehículo, constraints, errores de validación, tiempo de retorno, colisiones, uso de memoria y latencia percibida.
