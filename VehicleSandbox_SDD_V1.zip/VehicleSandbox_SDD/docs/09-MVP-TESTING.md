# 09 — Plan MVP y aceptación

## Fase 1 — Infraestructura
- Bootstrap, registro de servicios, 10 estaciones desde plantilla, catálogo, modelos y validaciones.
- Aceptación: 10 jugadores reciben bases diferentes; liberar/reasignar no deja restos; nuevo objeto se registra sin cambiar lógica central.

## Fase 2 — Construcción
- Editor local optimista, snap, rotación, borrado, inventario, permisos, acks y rollback.
- Aceptación: pieza aparece inmediatamente; rechazo servidor restaura estado; otro jugador no edita base ajena.

## Fase 3 — Simulación
- Vehículo con estructura, rueda, motor, tanque, asiento y propulsor; alternancia editar/conducir/regresar.
- Aceptación: vehículo conduce, se lanza centrado y vuelve idéntico al blueprint.

## Fase 4 — Daño modular
- Durabilidad temporal, impactos, desprendimientos, grafos de conexión y cleanup.
- Aceptación: una pieza rota deja de funcionar, grupos desconectados se separan, regresar restaura 100% HP sin pérdidas.

## Fase 5 — Economía
- Distancia, dinero, inventario persistente, cajas con rarezas, stock compartido y camión de entregas.
- Aceptación: no hay doble compra de último stock; entrega no se duplica; probabilidades configurables suman 100%; reconexión no pierde pedidos.

## Fases posteriores
- Misiones personales avanzadas, misiones de servidor, globales, decoraciones, variedad de motores, balance, UI completa y optimización.

## Matriz de pruebas esencial
1. Conectar 10 clientes y comprobar exclusividad de estaciones.
2. Colocar y borrar pieza durante ping elevado y comprobar reconciliación.
3. Lanzar, destruir motor, volver: motor idéntico y sin daño persistente.
4. Destruir puente de chasis: solo se desprende el componente desconectado.
5. Dos compradores simultáneos con stock 1: solo uno compra.
6. Desconexión tras comprar antes del camión: pedido recuperable.
7. Reiniciar servidor durante entrega: no duplicar inventario.
8. Reabrir caja en reconexión: no rerollear recompensa ya asignada.
9. Crear pieza nueva vía definición + modelo: editor y runtime la detectan.
10. Perfilado con 10 vehículos; registrar límites antes de prometer FPS o 0 ms.
