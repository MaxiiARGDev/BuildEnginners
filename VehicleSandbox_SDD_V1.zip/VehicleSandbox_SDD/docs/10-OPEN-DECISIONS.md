# 10 — Decisiones pendientes (no inventar)

## Mecánica
- ¿Vehículos pueden usar varias ruedas, motores, tanques y propulsores? Límites y fórmula de combinación.
- Significado de `eq` de neumáticos, `tasa de desconexión` de motores y unidades de combustible/impulso.
- Fórmula de velocidad, torque, agarre, combustible, bonos por conducción y ganancias por distancia.
- Combustible inicial y recarga entre intentos (propuesta: reset sin costo).
- Si al regresar se conserva el dinero ganado durante el intento y en qué condiciones.
- Cómo se define fin de intento: botón, muerte del personaje, destrucción de asiento, inmovilización, distancia máxima.
- Grid/snap, tamaño de estación, límites de bloques y colisiones permitidas.
- Cómo afectan al vehículo piezas conectadas por múltiples caminos.

## Economía
- Frecuencia del restock de tienda y catálogo exacto de objetos con stock limitado.
- Moneda o Robux para entrega exprés, precio y cumplimiento de compra.
- Política de pedidos al desconectarse o cambiar de servidor.
- Probabilidades exactas por caja, por tamaño y rareza; bonus final por rareza.
- Si se compra la caja o el motor y en qué momento se abre.

## Multijugador y mapa
- Si vehículos pueden interactuar o colisionar entre sí.
- Permisos de colaboración en base ajena (no confirmados).
- Reglas de spawn, obstáculos y streaming del mapa.
- Si misión global recompensa al primer jugador del universo o a varios.

## Técnica
- Herramienta de perfiles, librerías externas permitidas, convención de Rojo, compatibilidad móvil, guardado automático, límite de DataStore y políticas de migración.

Registrar cada decisión nueva con fecha y efecto en contratos antes de programarla.
